import Belleza from "./Belleza.png";
import Coaching from "./Coaching.png";
import Educación from "./Educacion.png";
import Farmacias from "./Farmacias.png";
import Restaurantes from "./Restaurantes.png";
import Tiendas from "./Tiendas.png";

const newCategories = {
  Belleza,
  Coaching,
  Educación,
  Farmacias,
  Restaurantes,
  Tiendas,
};

export default newCategories;
