export type Sector = {
    nombre: string
    id: number
}