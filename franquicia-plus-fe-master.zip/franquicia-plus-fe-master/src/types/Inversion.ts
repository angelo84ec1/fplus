export type Inversion = {
    nombre: string,
    nombre_url: string,
    id: number
}