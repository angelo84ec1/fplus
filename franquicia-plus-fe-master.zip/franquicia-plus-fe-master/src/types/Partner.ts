export type Partner = {
    id: number,
    imagensincolor: string,
    altimagensincolor: string,
    titleimagensincolor: string,
    imagenconcolor: string,
    altimagenconcolor: string,
    titleimagenconcolor: string,
    url: string,
    animation?: string
  }