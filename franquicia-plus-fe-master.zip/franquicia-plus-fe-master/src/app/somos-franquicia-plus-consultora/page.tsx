import AboutUsComponent from "./AboutUsComponent";

const AboutUs = () => {
  return (
    <>
      <AboutUsComponent />
    </>
  );
};

export default AboutUs;
