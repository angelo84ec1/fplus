import CertificateComponent from "./CertificateComponent";

const Certificate = () => {
  return (
    <>
      <CertificateComponent />
    </>
  );
};

export default Certificate;
