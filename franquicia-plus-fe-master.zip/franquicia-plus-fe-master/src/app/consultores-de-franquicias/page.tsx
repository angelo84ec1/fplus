import FrachisesPageComponent from "./FrachisesPageComponent";

const FrachisesPage = () => {
  return (
    <>
      <FrachisesPageComponent />
    </>
  );
};

export default FrachisesPage;
