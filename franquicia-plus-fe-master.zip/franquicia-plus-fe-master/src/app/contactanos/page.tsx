import ContactUsComponent from "./ContactUsComponent";

const ContactUs = () => {
  return (
    <>
      <ContactUsComponent />
    </>
  );
};

export default ContactUs;
