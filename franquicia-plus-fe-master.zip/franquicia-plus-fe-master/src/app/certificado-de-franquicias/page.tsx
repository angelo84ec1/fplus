import CertificatePageComponent from "./CertificatePageComponent";

const CertificatePage = () => {
  return (
    <>
      <CertificatePageComponent />
    </>
  );
};

export default CertificatePage;
